package com.syahril.modul1.tugas;

public class BiodataKaryawan {
    private static String nama = "Syahril";
    private static String asal = "Gorontalo";
    private static String umur = "19";
    private static String jeniskelamin = "Laki-laki";


    public static void main(String[] args) {

        // Output Biodata Karyawan
        System.out.println(" *** Biodata Karyawan  *** ");
        System.out.println("Nama Lengkap\t : " + nama);
        System.out.println("asal\t\t\t : " + asal);
        System.out.println("umur\t\t\t : " + umur);
        System.out.println("jeniskelamin\t : " + jeniskelamin);

    }
}